# Wellness Wayfinder

A comprehensive wellness application that helps users track their BMI, get personalized diet recommendations, and receive activity suggestions based on their health status.

## Features

- BMI Calculator with personalized recommendations
- Diet suggestions based on dietary preferences and financial status
- Activity recommendations based on BMI results
- User authentication system
- Responsive design with beautiful UI

## Tech Stack

- React
- TypeScript
- Tailwind CSS
- Vite
- Lucide React Icons

## Getting Started

1. Clone the repository
```bash
git clone [your-repo-url]
```

2. Install dependencies
```bash
npm install
```

3. Start the development server
```bash
npm run dev
```

4. Build for production
```bash
npm run build
```

## Live Demo

The application is deployed on Netlify: [Wellness Wayfinder](https://sage-unicorn-438b35.netlify.app)

## License

MIT